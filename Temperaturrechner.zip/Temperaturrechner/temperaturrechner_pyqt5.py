import sys,os
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLineEdit, QPushButton, QVBoxLayout, QLabel, QHBoxLayout
)
from PyQt5.QtGui import QDoubleValidator
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIcon

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(BASE_DIR, "thermometer.jpg")

class Myapp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Temperaturrechner")
        self.setWindowIcon(QIcon(ICON_PATH))
        self.resize(300, 150)

        layout = QVBoxLayout()
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(10)


        # Hinweis-Label (Rich text) + zum Layout hinzufügen
        label = QLabel('Was möchtest du umrechnen? (C → <span style="color:#d4a017">F</span> oder <span style="color:#d4a017">F</span> → C)')
        label.setTextFormat(Qt.RichText)
        layout.addWidget(label)

        # Eingaben
        self.eingabe_celsius = QLineEdit()
        self.eingabe_celsius.setPlaceholderText('Celsius in Fahrenheit')
        self.eingabe_celsius.setValidator(QDoubleValidator(self))
        layout.addWidget(self.eingabe_celsius)

        self.eingabe_fahrenheit = QLineEdit()
        self.eingabe_fahrenheit.setPlaceholderText('Fahrenheit in Celsius')
        self.eingabe_fahrenheit.setValidator(QDoubleValidator(self))
        layout.addWidget(self.eingabe_fahrenheit)

        # Button
        btn_row = QHBoxLayout()
        self.btn_celsius = QPushButton('Celsius -> Fahrenheit')
        self.btn_celsius.setObjectName('btn_celsius')

        self.btn_fahrenheit = QPushButton('Fahrenheit -> Celsius')
        self.btn_fahrenheit.setObjectName('btn_fahrenheit')

        btn_row.addWidget(self.btn_celsius)
        btn_row.addWidget(self.btn_fahrenheit)
        layout.addLayout(btn_row)

        # Ausgabe
        self.ausgabe = QLabel("")
        self.ausgabe.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.ausgabe)

        self.setLayout(layout)

        #Signale
        self.btn_celsius.clicked.connect(self.update_text_celsius)
        self.btn_fahrenheit.clicked.connect(self.update_text_fahrenheit)
        self.setStyleSheet("""
        /* Allgemein */
    QWidget {
        background-color: #90EE90;           /* hellgrün */
        color: #000000;
        font-family: "Segoe UI", Cantarell, Arial;
        font-size: 20px;
    }

    QLabel {
        background-color: #ffffff;           /* WEISSER Hintergrund fürs Label */
        border: 1px solid #334155;
        border-radius: 8px;
        padding: 6px 8px;
        color: #000000;
        font-size: 14px;
    }

    QLineEdit {
        background-color: #ffffff;
        color: #000000;
        border: 1px solid #334155;
        border-radius: 8px;
        padding: 6px 8px;
        font-size: 16px;
    }
    QLineEdit:focus {
        background-color: #ffffff;
        border: 1px solid #3b82f6;
    }

    QPushButton {
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        font-weight: bold;
        color: #ffffff;                      /* bessere Lesbarkeit auf kräftigen Farben */
    }

    /* Unterschiedliche Farben per objectName */
    QPushButton#btn_celsius   { background-color: #3b82f6; } /* Blau */
    QPushButton#btn_fahrenheit{ background-color: #f97316; } /* Orange */

    /* Hover/Pressed (optional je Button oder allgemein) */
    QPushButton#btn_celsius:hover    { filter: brightness(1.1); }
    QPushButton#btn_celsius:pressed  { filter: brightness(0.95); }

    QPushButton#btn_fahrenheit:hover { filter: brightness(1.1); }
    QPushButton#btn_fahrenheit:pressed{ filter: brightness(0.95); }
    """)



        self.show()


    def update_text_celsius(self):
        try:
            text = self.eingabe_celsius.text().strip()
            if not text:
                raise ValueError
            val = float(text)
            fahrenheit = (val * 9.0 / 5.0) + 32.0
            self.ausgabe.setText(f'{fahrenheit:.1f} °F')
        except ValueError:
            self.ausgabe.setText('Bitte eine Zahl bei Celsius eingeben.')



    def update_text_fahrenheit(self):
        try:
            text = self.eingabe_fahrenheit.text().strip()
            if not text:
                raise ValueError
            val = float(text)
            celsius = (val - 32.0) * 5.0 / 9.0
            self.ausgabe.setText(f'{celsius:.1f} °C')
        except ValueError:
            self.ausgabe.setText('Bitte eine Zahl bei Fahrenheit eingeben.')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Myapp()
    sys.exit(app.exec_())